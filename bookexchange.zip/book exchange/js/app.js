document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    fetch('api/register_user.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, email, password })
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
    });
});

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    fetch('api/login_user.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Login successful. User ID:', data.user_id);
        } else {
            console.log('Login failed:', data.message);
        }
    });
});

document.getElementById('addBookForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const title = document.getElementById('bookTitle').value;
    const author = document.getElementById('bookAuthor').value;
    const description = document.getElementById('bookDescription').value;
    const price = document.getElementById('bookPrice').value;
    const user_id = 15; // Assume logged-in user ID is 1 for this example
	
console.log("Podaci koji se šalju:", data);	
	

    fetch('api/add_book.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title, author, description, price, user_id })
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
    });
});

document.getElementById('getBooks').addEventListener('click', function() {
    fetch('api/get_books.php')
    .then(response => response.json())
    .then(data => {
        const bookList = document.getElementById('bookList');
        bookList.innerHTML = '';

        data.books.forEach(book => {
            const li = document.createElement('li');
            li.textContent = `${book.title} by ${book.author} - $${book.price} (Owner: ${book.owner.username})`;
            bookList.appendChild(li);
        });
    });
});