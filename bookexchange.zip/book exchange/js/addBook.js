document.addEventListener('DOMContentLoaded', function() {
    const addBookForm = document.getElementById('addBookForm');
    if (addBookForm) {
        addBookForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const title = document.getElementById('bookTitle').value;
            const author = document.getElementById('bookAuthor').value;
            const description = document.getElementById('bookDescription').value;
            const price = document.getElementById('bookPrice').value;

            // Retrieve user_id from localStorage
            const userId = localStorage.getItem('user_id');

            if (userId) {
                // Prepare data object to send to server
                const bookData = {
                    title: title,
                    author: author,
                    description: description,
                    price: price,
                    user_id: userId // Include user_id in the data object
                };

                // Send bookData to server using fetch
                fetch('api/add_book.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(bookData)
                })
                .then(response => response.json())
                .then(data => {
                    console.log(data.message); // Log server response message
                    // Optionally, you can display a success message to the user
                })
                .catch(error => {
                    console.error('Error adding book:', error);
                    // Handle error appropriately (e.g., display error message to user)
                });
            } else {
                console.error('User ID not found in localStorage.');
                // Handle case where user_id is not available (e.g., redirect to login page)
            }
        });
    } else {
        console.error('Element with ID "addBookForm" not found.');
    }

    // Function to fetch and display books
    const getBooks = function() {
        fetch('api/get_books.php')
        .then(response => response.json())
        .then(data => {
            const bookList = document.getElementById('bookList');
            bookList.innerHTML = '';

            data.books.forEach(book => {
                const li = document.createElement('li');
                li.textContent = `${book.title} by ${book.author} - $${book.price} (Owner: ${book.owner.username})`;
                bookList.appendChild(li);
            });
        })
        .catch(error => {
            console.error('Error fetching books:', error);
            // Handle error appropriately (e.g., display error message to user)
        });
    };

    // Call getBooks function immediately to fetch and display books
    getBooks();

    // Optionally, you can add event listener to a button to fetch books again
    const getBooksButton = document.getElementById('getBooks');
    if (getBooksButton) {
        getBooksButton.addEventListener('click', getBooks);
    } else {
        console.error('Element with ID "getBooks" not found.');
    }
});