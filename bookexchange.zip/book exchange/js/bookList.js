document.addEventListener('DOMContentLoaded', function() {
    const getBooksButton = document.getElementById('getBooks');
    if (getBooksButton) {
        getBooksButton.addEventListener('click', function() {
            fetch('api/get_books.php')
            .then(response => response.json())
            .then(data => {
                const bookList = document.getElementById('bookList');
                bookList.innerHTML = '';

                data.books.forEach(book => {
                    const li = document.createElement('li');
                    li.textContent = `${book.title} by ${book.author} - $${book.price} (Owner: ${book.owner.username}), Email: ${book.owner.email})`;
                    bookList.appendChild(li);
                });
            });
        });
    } else {
        console.error('Element with ID "getBooks" not found.');
    }
});