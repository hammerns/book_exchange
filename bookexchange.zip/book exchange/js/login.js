document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;

            fetch('api/login_user.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Login successful. User ID:', data.user_id);
                    
                    // Save user_id to localStorage or sessionStorage
                    localStorage.setItem('user_id', data.user_id);
                    
                    // Redirect to add book page after successful login
                    window.location.href = 'AddBook.html'; // Adjust URL as needed
                } else {
                    console.log('Login failed:', data.message);
                    alert('Login failed. ' + data.message); // Example of alert message
                }
            })
            .catch(error => {
                console.error('Error during login:', error);
                alert('An error occurred during login. Please try again.'); // Example of error handling
            });
        });
    } else {
        console.error('Element with ID "loginForm" not found.');
    }
});