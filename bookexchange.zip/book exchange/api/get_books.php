<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'Database.php';

$database = new Database();
$db = $database->getConnection();

// Provera konekcije
if ($db === null) {
    die("Connection failed: Unable to connect to the database.");
}

// Kreiranje niza za čuvanje podataka
$response = array();

// Izvršavanje upita za dobijanje podataka o knjigama zajedno sa vlasnicima
$sqlBooks = "SELECT books.id, books.title, books.author, books.description, books.price, users.id as user_id, users.username, users.email FROM books LEFT JOIN users ON books.user_id = users.id";
$resultBooks = $db->query($sqlBooks);

$books = array();
if ($resultBooks->rowCount() > 0) {
    while($row = $resultBooks->fetch(PDO::FETCH_ASSOC)) {
        $book = array(
            "id" => $row['id'],
            "title" => $row['title'],
            "author" => $row['author'],
            "description" => $row['description'],
            "price" => $row['price'],
            "owner" => array(
                "id" => $row['user_id'],
                "username" => $row['username'],
                "email" => $row['email']
            )
        );
        $books[] = $book;
    }
    $response['books'] = $books;
} else {
    $response['books'] = array("message" => "Nema knjiga.");
}

// Konverzija niza u JSON format i ispisivanje
echo json_encode($response);

$db = null; // Zatvaranje veze s bazom podataka
?>