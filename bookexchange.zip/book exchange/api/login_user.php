<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

include_once 'Database.php';
include_once 'User.php';

$database = new Database();
$db = $database->getConnection();

$user = new User($db);

$data = json_decode(file_get_contents("php://input"));

$user->email = $data->email;
$user->password = $data->password;

if ($user->login()) {
    echo json_encode(array(
        "success" => true,
        "message" => "Login successful.",
        "user_id" => $user->id,
        "username" => $user->username
    ));
} else {
    echo json_encode(array("message" => "Login failed."));
}
?>