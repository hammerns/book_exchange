<?php
class Database {
    private $host = "sql200.infinityfree.com";
    private $db_name = "epiz_31121671_book_exchange";
    private $username = "epiz_31121671";
    private $password = "7XhEahxb5zgcPgN";
    public $conn;

    public function getConnection(){
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        return $this->conn;
    }
}
?>