<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

include_once 'Database.php';
include_once 'Book.php';

$database = new Database();
$db = $database->getConnection();

$book = new Book($db);

$data = json_decode(file_get_contents("php://input"));

$book->title = $data->title;
$book->author = $data->author;
$book->description = $data->description;
$book->user_id = $data->user_id;
$book->price = $data->price;

if ($book->addBook()) {
    echo json_encode(array("message" => "Knjiga je uspešno dodata."));
} else {
    echo json_encode(array("message" => "Greška pri dodavanju knjige."));
}
?>